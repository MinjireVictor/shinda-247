const games = [
    {
        id: 1,
        name: "Crash",
        prefix: "crash",
        surfix: "crash",
        image: "/assets/images/covers_new/crash.png",
        color: 'linear-gradient(110deg, rgb(233, 30, 99) 0%, #ffc107 100%)',
        icon: "dripicons-rocket",
        desc: "Boost Your Profit",
        hedge: 1
    }
];

export default games;